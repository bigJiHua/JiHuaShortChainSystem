const config = require('../config')
const { ExecuteFunctionData } = require('../Implement/ExecuteFunction')

// 获取用户代办
exports.toJumpRouter = (req,res) => {
    res.send("alert('Hello World!')");
}
